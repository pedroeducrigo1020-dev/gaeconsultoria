# Ethos e Terra — projeto organizado

Reorganização dos arquivos enviados, com nomes claros seguindo o
sitemap (`SITEMAP.txt`) e os bugs abaixo corrigidos.

## Estrutura

```
index.html                 Home ← gerado agora
gestao-ambiental.html      Hub central (página-mãe)
seguranca-trabalho.html    Pilar 01
marketing.html             Pilar 02  ← gerado
qualidade.html             Pilar 03  ← gerado
filosofia-empresa.html     Pilar 04  ← gerado
rh.html                    Pilar 05  ← gerado
ti.html                    Pilar 06  ← gerado
nr-01.html, nr-35.html, pgr-pcmso.html                              (sub-sub, Segurança)
branding-esg.html, marketing-digital.html, comunicacao-interna.html (sub-sub, Marketing)
iso-9001.html, iso-14001.html, auditorias.html                      (sub-sub, Qualidade)
missao-visao-valores.html, codigo-conduta.html, governanca.html     (sub-sub, Filosofia)
recrutamento.html, clima-psicossocial.html, treinamento-lideranca.html (sub-sub, RH)
infraestrutura.html, seguranca-informacao.html, lgpd-dados.html     (sub-sub, TI)

assets/
├── hub.css       (corrigido + ampliado)
├── app.js        (corrigido)
└── subpages.js   (corrigido)
```

Somente `nr-35.html`, `seguranca-trabalho.html` e `gestao-ambiental.html`
vieram prontos. Os outros 17 sub-sub e 5 pilares foram **gerados a
partir do mesmo template**, já que os dados (título, lead, bullets, FAQ)
já existiam em `subpages.js` ou nos `<p>` dos cards do hub — só faltava
o HTML/CSS de cada arquivo.

## Bugs corrigidos

1. **CSS ausente para `.card-servico`** — as páginas de pilar (ex.
   `seguranca-trabalho.html`) usam as classes `.card-servico`,
   `.card__num`, `.card__icone`, `.card__link` para o grid das
   sub-sub-páginas, mas o `hub.css` original só estilizava
   `.pilar-card` (usado no hub). Isso deixava esses cards sem nenhum
   visual. Adicionei o bloco `.card-servico` em `hub.css`, espelhando
   o comportamento do `.pilar-card`.
2. **Rótulo inconsistente "NR-1" vs "NR-01"** — em `subpages.js`, os
   blocos de estatística de `nr-01` e `clima-psicossocial` usavam
   "NR-1", enquanto o título da própria página e o resto do site usam
   "NR-01". Padronizado para "NR-01".
3. **`app.js` fora de uma IIFE** — o comentário original pedia para
   colar o trecho "dentro do IIFE existente", mas o arquivo declarava
   `initReveal`, `initFAQ`, `initCounters` e `initAll` no escopo
   global. Agora está todo dentro de uma IIFE própria.
4. **Sem proteção contra religação duplicada de listeners/observers**
   — como `initAll()` roda de novo a cada `ethos:subpage-rendered`,
   adicionei guardas (`data-reveal-bound`, `data-faq-bound`,
   `data-counter-bound`) para nunca observar/ligar o mesmo elemento
   duas vezes, e um guard equivalente (`main.dataset.rendered`) em
   `subpages.js` para não renderizar a mesma `<main>` duas vezes.
5. **Render de subpage sem tratamento de erro** — se qualquer campo
   de uma entrada em `SUBPAGES` estivesse ausente, `main.innerHTML`
   quebraria silenciosamente ou lançaria erro não tratado. Agora o
   template está isolado em `renderTemplate()` e envolto em
   `try/catch`, com fallback visível em caso de falha.

## O que ainda falta (não veio nos arquivos enviados)

Estes itens são referenciados pelos arquivos, mas não foram enviados —
não inventei o conteúdo/design deles para não divergir do que você já
tem:

- **`assets/styles.css`** — a folha de estilo base (variáveis de cor,
  tipografia, `.container`, `.btn`, `.faq`, `.timeline`, `.cta-final`
  etc.). Sem ela, nada tem estilo além do que está em `hub.css`.
- **`contato.html`**, **`metodo.html`** — linkados em vários lugares,
  mas não enviados.
- **Conteúdo real de `#site-header` / `#site-footer`** — os `<div>`
  existem no HTML, mas nada os popula. O `app.js` original
  provavelmente fazia isso (o comentário menciona um IIFE "maior");
  esse trecho não foi enviado.
- **`[data-contar]` agora está em uso** — conectado em `index.html`:
  os números "-34%", "180+", "60%" e "100%" na home animam ao entrar
  na tela. As páginas de pilar (ex. `seguranca-trabalho.html`, que
  ainda tem "-60%" estático) podem receber o mesmo tratamento se você
  quiser o efeito lá também.

Quer que eu monte os arquivos que ainda faltam (`contato.html`,
`metodo.html`, `styles.css`, header/footer)?
