/* ============================================================
   assets/app.js
   Comportamentos globais do site: reveal-on-scroll, acordeão de
   FAQ e contadores animados.

   NOTA IMPORTANTE (organização):
   O arquivo original vinha com o comentário "Adicione dentro do
   IIFE, no lugar dos blocos existentes", indicando que este trecho
   deveria ser colado dentro de um app.js maior — que também cuida
   de coisas como carregar o header/footer (#site-header /
   #site-footer) e o menu mobile. Esse app.js "base" não foi
   enviado, então essas funções continuam ausentes aqui. Ver
   README.md para a lista completa de pendências.

   BUGS CORRIGIDOS nesta versão:
   1. Todo o código agora vive dentro de uma IIFE própria (como o
      comentário original pedia), em vez de declarar funções no
      escopo global.
   2. initFAQ() e initReveal()/initCounters() agora marcam os
      elementos já inicializados (data-bound / classes de estado)
      antes de religar listeners ou observers. Isso evita
      vazamento de memória e handlers duplicados caso
      window.EthosInit / o evento 'ethos:subpage-rendered' disparem
      mais de uma vez no ciclo de vida da página.
   ============================================================ */
(function () {
  'use strict';

  function initReveal() {
    const alvos = document.querySelectorAll('.revelar:not([data-reveal-bound]), .revelar-stagger:not([data-reveal-bound])');
    if (!alvos.length) return;

    if ('IntersectionObserver' in window) {
      const obs = new IntersectionObserver(entradas => {
        entradas.forEach(e => {
          if (e.isIntersecting) {
            e.target.classList.add('visivel');
            obs.unobserve(e.target);
          }
        });
      }, { threshold: .1, rootMargin: '0px 0px -60px 0px' });

      alvos.forEach(el => {
        el.dataset.revealBound = '1';
        obs.observe(el);
      });
    } else {
      alvos.forEach(el => {
        el.dataset.revealBound = '1';
        el.classList.add('visivel');
      });
    }
  }

  function initFAQ() {
    document.querySelectorAll('.faq__pergunta:not([data-faq-bound])').forEach(btn => {
      btn.dataset.faqBound = '1';
      btn.addEventListener('click', () => {
        const item = btn.parentElement;
        const aberto = item.classList.contains('aberto');

        document.querySelectorAll('.faq__item').forEach(i => {
          i.classList.remove('aberto');
          const b = i.querySelector('.faq__pergunta');
          if (b) b.setAttribute('aria-expanded', 'false');
        });

        if (!aberto) {
          item.classList.add('aberto');
          btn.setAttribute('aria-expanded', 'true');
        }
      });
    });
  }

  function initCounters() {
    const nums = document.querySelectorAll('[data-contar]:not([data-counter-bound])');
    if (!('IntersectionObserver' in window) || !nums.length) return;

    const obsN = new IntersectionObserver(entradas => {
      entradas.forEach(e => {
        if (!e.isIntersecting) return;
        const el = e.target;
        const fim = parseInt(el.dataset.contar, 10);
        const sufixo = el.dataset.sufixo || '';
        if (Number.isNaN(fim)) { obsN.unobserve(el); return; }

        const dur = 1500, ini = performance.now();
        (function passo(a) {
          const p = Math.min((a - ini) / dur, 1);
          el.textContent = Math.round(fim * (1 - Math.pow(1 - p, 3))) + sufixo;
          if (p < 1) requestAnimationFrame(passo);
        })(ini);

        obsN.unobserve(el);
      });
    }, { threshold: .5 });

    nums.forEach(n => {
      n.dataset.counterBound = '1';
      obsN.observe(n);
    });
  }

  function initAll() {
    initReveal();
    initFAQ();
    initCounters();
  }

  window.EthosInit = initAll;
  document.addEventListener('ethos:subpage-rendered', initAll);

  // Primeira rodada (funciona tanto em páginas normais quanto,
  // após o render do subpages.js, no restante do conteúdo).
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
